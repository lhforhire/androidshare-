
package com.example.remote;

import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private MediaProjectionManager mediaProjectionManager;
    private MediaProjection mediaProjection;
    private static final int REQUEST_MEDIA_PROJECTION = 1001;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button playButton = findViewById(R.id.playButton);
        Button stopButton = findViewById(R.id.stopButton);
        Button shareButton = findViewById(R.id.shareButton);

        mediaProjectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

        playButton.setOnClickListener(v -> requestMediaProjection());
        stopButton.setOnClickListener(v -> stopStreaming());
        shareButton.setOnClickListener(v -> shareStream());
    }

    private void requestMediaProjection() {
        if (mediaProjectionManager != null) {
            Intent intent = mediaProjectionManager.createScreenCaptureIntent();
            startActivityForResult(intent, REQUEST_MEDIA_PROJECTION);
        } else {
            Toast.makeText(this, "MediaProjectionManager not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data);
                startStreaming();
            } else {
                Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startStreaming() {
        // Implement Firestick-specific streaming logic here
        if (mediaProjection != null) {
            Toast.makeText(this, "Streaming started", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "MediaProjection not initialized", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopStreaming() {
        if (mediaProjection != null) {
            mediaProjection.stop();
            mediaProjection = null;
            Toast.makeText(this, "Streaming stopped", Toast.LENGTH_SHORT).show();
        }
    }

    private void shareStream() {
        // Share stream URL logic
        Toast.makeText(this, "Sharing stream URL", Toast.LENGTH_SHORT).show();
    }
}
